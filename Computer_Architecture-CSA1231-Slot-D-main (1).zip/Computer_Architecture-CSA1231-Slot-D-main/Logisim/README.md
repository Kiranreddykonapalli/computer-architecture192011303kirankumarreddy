AND Gate

NAND Gate

OR Gate

NOR Gate

XOR Gate

XNOR Gate

NOT Gate

Buffer Gate

Half Adder Circuit

Full Adder Circuit

Half Subtractor Circuit

Full Subtractor Circuit
