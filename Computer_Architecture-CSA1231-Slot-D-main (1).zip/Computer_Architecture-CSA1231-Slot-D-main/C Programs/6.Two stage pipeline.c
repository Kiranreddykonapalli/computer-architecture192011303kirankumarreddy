#include<stdio.h>
int main()
{
	int counter =1,a,b,choice,res,ins;
	printf("Enter number 1:");
	scanf("%d",&a);
	counter = counter+1;
	printf("Enter number 2:");
	scanf("%d",&b);
	counter = counter +1;
	printf("1-Addition:\n2-Subtraction:\n3-Multiplication:\n4-Division:");
	scanf("%d",&choice);
	switch(choice)
	{
		case 1: printf("Performing addition\n");
				res = a+b;
				counter = counter+1;
				break;
		case 2: printf("Performing subtraction\n");
				res = a-b;
				counter = counter+1;
				break;
		case 3: printf("Performing Multiplication\n");
				res = a*b;
				counter = counter+1;
				break;
		case 4: printf("Performing Division\n");
				res = a/b;
				counter = counter+1;
				break;
		default: printf("Wrong input");
				break;
	}
	printf("The cycle value is:%d\n",counter);
	printf("Enter the number of instructions:");
	scanf("%d",&ins);
	int performance_measure = ins/counter;
	printf("The performance measure is:%d\n",performance_measure);
	return 0;
	
}
