# Computer_Architecture-CSA1231-Slot-D

1.8 bit Addition

2.8 bit Subtraction

3.8 bit Multiplication

4.8 bit Division

5.16 bit Addition

6.16 bit Addition using DAD

7.16 bit Subtraction

8.16 bit Multiplication

9.16 bit Division

10.AND Operation

11.OR Operation

12.EXOR Operation

13.Factorial of n number

14.Swaping

15.Smallest number in array

16.Largest number in array

17.Square of the number

18.Sum of n numbers

19.RLC

20.RRC

21.Ascending order

22.Descending order

23.16 bit 1's and 2's Compliment

24.8 bit 1's and 2's Compliment
